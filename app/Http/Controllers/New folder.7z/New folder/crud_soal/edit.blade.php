@extends('layouts.guru')
@section('title', 'Edit')
@section('content')

@endsection